2020-11-20
* Updates to Visio stencils.
* Addition of OmniGraffle stencils and procedure.
* Addition of PowerPoint stencils.
* Addition of .svg files.

2019-10-03
* Corrected issues with the vmware-sddc-icons.vssx file, added vmware-sddc-template.vsdx, and repackaged.

2019-05-31
* Extensive product and feature icons additions and updates.
* Added low- and mid-complexity example diagrams.

2018-08-14:
* Initial publication.